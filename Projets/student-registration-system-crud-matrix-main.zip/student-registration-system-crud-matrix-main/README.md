# student-registration-system-crud-matrix

install pymysql for mysql connection
command: 

pip install PyMySQL
